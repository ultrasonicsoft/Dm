﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultrasonic.DownloadManager.Controls
{
    public enum ComboViewSelectionMode
    {
        Normal,
        Confirm
    }
}
