﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultrasonic.DownloadManager.Controls
{
    public enum ItemTypeCheckRecordMode
    {
        All = 0,
        LeafOnly = 1
    }
}
