﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Net;
using System.IO;
using WatiN.Core;
using WatiN.Core.DialogHandlers;
using System.Threading;
using System.Threading.Tasks;

namespace Ultrasonic.DownloadManager
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        StringBuilder loggingInformation = new StringBuilder();
        public Login()
        {
            InitializeComponent();
        }

        private void TermsOfPaysafecard_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            Process.Start("http://www.paysafecard.com/index.php?id=823&L=39");
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Wait frmWait = new Wait();
            try
            {
                MessageBox.Show("Please wait... This will take few minutes...");

                Mouse.OverrideCursor = Cursors.Wait;

                //Settings.Instance.MakeNewIeInstanceVisible = false;
                
                loggingInformation.Append(DateTime.Now.ToShortTimeString() + Environment.NewLine);
                IE explore = new IE();
                explore.ClearCache();
                explore.ClearCookies();
                explore.WaitForComplete();

                loggingInformation.Append("Creating  10minutemail new email id" + Environment.NewLine);
                explore.GoTo(Helper._10_MINUTE_MAIL_URL);
                explore.WaitForComplete();
                string emailID = explore.TextField(Find.ById("addyForm:addressSelect")).Value;

                loggingInformation.Append("emailID is : " + emailID + Environment.NewLine);

                loggingInformation.Append("Creating Uploaded.net new account with 10minute email id" + Environment.NewLine);

                CreateUploadLogin(emailID);

                loggingInformation.Append("Account created" + Environment.NewLine);

                loggingInformation.Append("Reading welcome email from uploaded.net" + Environment.NewLine);

                bool isConfirmationMailArrived = false;

                string confirmationUrl = string.Empty;

                while (!isConfirmationMailArrived)
                {
                    Thread.Sleep(20000);
                    explore.GoTo(Helper.CONFIRMATION_EMAIL_URL);
                    explore.WaitForComplete();

                    loggingInformation.Append("Extracting confirmation url" + Environment.NewLine);

                     confirmationUrl = GetConfirmationMailId(explore.Html);
                    if (!string.IsNullOrEmpty(confirmationUrl))
                    {
                        isConfirmationMailArrived = true;
                    }
                }
                loggingInformation.Append("Confirmation url: " + Environment.NewLine);

                loggingInformation.Append("Hitting Confirmation url " + Environment.NewLine);

                IE uploadedExplorer = new IE(confirmationUrl);

                loggingInformation.Append("Reading username password email " + Environment.NewLine);

                Thread.Sleep(20000);
                explore.GoTo("http://10minutemail.com/10MinuteMail/index.html?dataModelSelection=message%3Aemails%5B1%5D&actionMethod=index.xhtml%3AmailQueue.select");
                explore.WaitForComplete();
                string newAccountId;
                string newPassword;

                loggingInformation.Append("Extracting username password email " + Environment.NewLine);

                GetAccountIdAndPassword(explore, out newAccountId, out newPassword);

                loggingInformation.Append("username: " + newAccountId + Environment.NewLine + "password: " + newPassword + Environment.NewLine);

                PremiumPeriod period = PremiumPeriod._48Hours;
                if (rbtn48Hours.IsChecked == true)
                {
                    period = PremiumPeriod._48Hours;
                }
                else if (rbtn1Month.IsChecked == true)
                {
                    period = PremiumPeriod._1Month;
                }
                else if (rbtn3Months.IsChecked == true)
                {
                    period = PremiumPeriod._3Months;
                }
                else if (rbtn6Months.IsChecked == true)
                {
                    period = PremiumPeriod._6Months;
                }
                else if (rbtn1Year.IsChecked == true)
                {
                    period = PremiumPeriod._1Year;
                }

                string paysafe_pin1 = txtpaysafe_pin1.Text;
                string paysafe_pin2 = txtpaysafe_pin2.Text;
                string paysafe_pin3 = txtpaysafe_pin3.Text;
                string paysafe_pin4 = txtpaysafe_pin4.Text;

                bool finalStautus = RegisterForPremiumAccountWithReference(uploadedExplorer, period, emailID, paysafe_pin1, paysafe_pin2, paysafe_pin3, paysafe_pin4);
                //bool status = RegisterForPremiumAccount(newAccountId, newPassword, period, emailID, paysafe_pin1, paysafe_pin2, paysafe_pin3, paysafe_pin4);

                explore.Close();
                MessageBox.Show("Registration successful");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                File.WriteAllText(Helper.LOGGING_FILE_PATH, loggingInformation.ToString());
                Mouse.OverrideCursor = null;
                frmWait.Close();
            }
        }

        private bool RegisterForPremiumAccountWithReference(IE uploadedExplorer, PremiumPeriod period, string emailID, string paysafe_pin1, string paysafe_pin2, string paysafe_pin3, string paysafe_pin4)
        {
            bool result = false;
            try
            {
                loggingInformation.Append("Redirect to Register page " + Environment.NewLine);

                uploadedExplorer.GoTo("http://Ul.to/ref/6335349");
                uploadedExplorer.WaitForComplete();

                bool isValidPeriod = false;
                switch (period)
                {
                    case PremiumPeriod._48Hours:
                        loggingInformation.Append("Selecting premium registration duration 2 days " + Environment.NewLine);
                        uploadedExplorer.GoTo(Helper._2_DAYS_PREMIUM_DURATION_URL);
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._1Month:
                        loggingInformation.Append("Selecting premium registration duration 1 month " + Environment.NewLine);
                        uploadedExplorer.GoTo(Helper._1_MONTH_PREMIUM_DURATION_URL);
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._3Months:
                        loggingInformation.Append("Selecting premium registration duration 3 month " + Environment.NewLine);
                        uploadedExplorer.GoTo(Helper._3_MONTHS_PREMIUM_DURATION_URL);
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._6Months:
                        loggingInformation.Append("Selecting premium registration duration 6 month " + Environment.NewLine);
                        uploadedExplorer.GoTo(Helper._6_MONTHS_PREMIUM_DURATION_URL);
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._1Year:
                        loggingInformation.Append("Selecting premium registration duration 1 year " + Environment.NewLine);
                        uploadedExplorer.GoTo(Helper._1_YEAR_PREMIUM_DURATION_URL);
                        isValidPeriod = true;
                        break;
                }

                if (isValidPeriod)
                {
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Check terms and condition check box " + Environment.NewLine);
                    uploadedExplorer.CheckBox(Find.ById("pinForm:acceptTerms")).Checked = true;
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Entering paysafe pin 1: " + paysafe_pin1 + Environment.NewLine);
                    uploadedExplorer.TextField(Find.ById("pinForm:rn01")).TypeText(paysafe_pin1);
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Entering paysafe pin 2: " + paysafe_pin2 + Environment.NewLine);
                    uploadedExplorer.TextField(Find.ById("pinForm:rn02")).TypeText(paysafe_pin2);
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Entering paysafe pin 3: " + paysafe_pin3 + Environment.NewLine);
                    uploadedExplorer.TextField(Find.ById("pinForm:rn03")).TypeText(paysafe_pin3);
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Entering paysafe pin 4: " + paysafe_pin4 + Environment.NewLine);
                    uploadedExplorer.TextField(Find.ById("pinForm:rn04")).TypeText(paysafe_pin4);
                    uploadedExplorer.WaitForComplete();

                    loggingInformation.Append("Submitting paysafe pin code for registration " + Environment.NewLine);
                    uploadedExplorer.Button(Find.ById("pinForm:pay")).ClickNoWait();
                    uploadedExplorer.WaitForComplete();
                    loggingInformation.Append("Submitting finished " + Environment.NewLine);

                }
                loggingInformation.Append("Logging out of uploaded.net " + Environment.NewLine);
                uploadedExplorer.GoTo("http://uploaded.net/logout");
                uploadedExplorer.WaitForComplete();
                loggingInformation.Append("Log out successful. " + Environment.NewLine);

                uploadedExplorer.Close();
                uploadedExplorer.WaitForComplete();
                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return result;
        }

        private void GetAccountIdAndPassword(IE explorer, out string newAccountId, out string newPassword)
        {
            newAccountId = string.Empty;
            newPassword = string.Empty;
            try
            {
                string htmlContent = explorer.Html;

                string[] allLines = htmlContent.Split('\n');
                foreach (string line in allLines)
                {
                    if (line.Contains("Account-ID:") || line.Contains("Password:"))
                    {
                        string accountId = line.Trim();
                        string[] tempLines = line.Split('>');
                        foreach (string innerLine in tempLines)
                        {
                            if (innerLine.Contains("Account-ID:"))
                            {
                                string temp = innerLine.Replace("<", string.Empty).Replace("BR", string.Empty).Replace("br", string.Empty).Trim();
                                newAccountId = temp.Split(':')[1].Trim();
                            }
                            if (innerLine.Contains("Password:"))
                            {
                                string temp = innerLine.Replace("<", string.Empty).Replace("BR", string.Empty).Replace("br", string.Empty).Trim();
                                newPassword = temp.Split(':')[1].Trim();
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);
            }
        }
        private string GetConfirmationMailId(string htmlContent)
        {
            string confirmationUrl = string.Empty;

            string[] allLines = htmlContent.Split('\n');
            foreach (string line in allLines)
            { 
                if (line.Contains("http://uploaded.net/welcome"))
                {
                    confirmationUrl = line.Replace("<br>", string.Empty).Replace("</br>", string.Empty).Trim();
                    break;                  
                }
            }
            return confirmationUrl;
        }
                
        private void CreateUploadLogin(string emailID)
        {
            try
            {
                Dictionary<string, string> RequestCookies = new Dictionary<string, string>();
                string url = "http://uploaded.net/io/register/free";
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
                request.Referer = "http://uploaded.net/register";
                request.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
                request.Method = "POST";
                request.ServicePoint.Expect100Continue = false;

                string postData = "mail=" + emailID;
                //string postData = "mail=freelanc1.john@gmail.com";

                var data = Encoding.ASCII.GetBytes(postData);
                request.ContentLength = data.Length;

                request.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip,deflate,sdch");
                string domain = string.Empty;

                var cookieContainer = new CookieContainer();

                if (RequestCookies != null && RequestCookies.Count > 0)
                {
                    foreach (string key in RequestCookies.Keys)
                    {
                        var cookie = new Cookie(key, RequestCookies[key], "/", domain);
                        cookieContainer.Add(cookie);
                    }
                }
                request.CookieContainer = cookieContainer;

                var requestStream = request.GetRequestStream();
                requestStream.Write(data, 0, data.Length);
                requestStream.Close();

                var myHttpWebResponse = (HttpWebResponse)request.GetResponse();
                
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private bool RegisterForPremiumAccount(string accountId, string password, PremiumPeriod period, string emailId, string paysafe_pin1, string paysafe_pin2, string paysafe_pin3, string paysafe_pin4)
        {
            bool result = false;
            try
            {
                //IE myIE = new IE("http://uploaded.net/#login");

                //myIE.WaitForComplete();
                //if (myIE.Forms.Count >= 2)
                //{
                //    myIE.Div("login").TextField(Find.ByName("id")).TypeText(accountId);
                //    myIE.Div("login").TextField(Find.ByName("pw")).TypeText(password);
                //    myIE.Div("login").TextField(Find.ByName("pw")).TypeText(password);

                //    PromptDialogHandler promptDialog = new PromptDialogHandler(true);
                //    ConfirmDialogHandler handler = new ConfirmDialogHandler();
                //    using (new UseDialogOnce(myIE.DialogWatcher, handler))
                //    {
                //        myIE.AddDialogHandler(promptDialog);
                //        myIE.Div("login").Button(Find.By("type", "submit")).ClickNoWait();
                //        handler.OKButton.Click();
                //    }
                //}

                //myIE.WaitForComplete();

                loggingInformation.Append("Redirect to Register page " + Environment.NewLine);

                IE myIE = new IE("http://Ul.to/ref/6335349");

                //myIE.GoTo("http://Ul.to/ref/6335349");
                myIE.WaitForComplete();

                bool isValidPeriod = false;
                switch (period)
                {
                    case PremiumPeriod._48Hours:
                        loggingInformation.Append("Selecting premium registration duration 2 days " + Environment.NewLine);
                        myIE.GoTo("http://uploaded.net/register/pay/PRM-D2/paysafe");
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._1Month:
                        loggingInformation.Append("Selecting premium registration duration 1 month " + Environment.NewLine);
                        myIE.GoTo("http://uploaded.net/register/pay/PRM-M1/paysafe");
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._3Months:
                        loggingInformation.Append("Selecting premium registration duration 2 month " + Environment.NewLine);
                        myIE.GoTo("http://uploaded.net/register/pay/PRM-M3/paysafe");
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._6Months:
                        loggingInformation.Append("Selecting premium registration duration 6 month " + Environment.NewLine);
                        myIE.GoTo("http://uploaded.net/register/pay/PRM-M6/paysafe");
                        isValidPeriod = true;
                        break;
                    case PremiumPeriod._1Year:
                        loggingInformation.Append("Selecting premium registration duration 1 year " + Environment.NewLine);
                        myIE.GoTo("http://uploaded.net/register/pay/PRM-Y1/paysafe");
                        isValidPeriod = true;
                        break;
                }

                if (isValidPeriod)
                {
                    myIE.WaitForComplete();

                    loggingInformation.Append("Check terms and condition check box " + Environment.NewLine);
                    myIE.CheckBox(Find.ById("pinForm:acceptTerms")).Checked = true;
                    myIE.WaitForComplete();

                    loggingInformation.Append("Entering paysafe pin 1: " + paysafe_pin1 + Environment.NewLine);
                    myIE.TextField(Find.ById("pinForm:rn01")).TypeText(paysafe_pin1);
                    myIE.WaitForComplete();
                    
                    loggingInformation.Append("Entering paysafe pin 2: " + paysafe_pin2 + Environment.NewLine);
                    myIE.TextField(Find.ById("pinForm:rn02")).TypeText(paysafe_pin2);
                    myIE.WaitForComplete();
                    
                    loggingInformation.Append("Entering paysafe pin 3: " + paysafe_pin3 + Environment.NewLine);
                    myIE.TextField(Find.ById("pinForm:rn03")).TypeText(paysafe_pin3);
                    myIE.WaitForComplete();
                    
                    loggingInformation.Append("Entering paysafe pin 4: " + paysafe_pin4 + Environment.NewLine);
                    myIE.TextField(Find.ById("pinForm:rn04")).TypeText(paysafe_pin4);
                    myIE.WaitForComplete();

                    loggingInformation.Append("Submitting paysafe pin code for registration " + Environment.NewLine);
                    myIE.Button(Find.ById("pinForm:pay")).ClickNoWait();
                    myIE.WaitForComplete();
                    loggingInformation.Append("Submitting finished " + Environment.NewLine);

                }
                loggingInformation.Append("Logging out of uploaded.net " + Environment.NewLine);
                myIE.GoTo("http://uploaded.net/logout");
                myIE.WaitForComplete();
                loggingInformation.Append("Log out successful. " + Environment.NewLine);

                myIE.Close();
                myIE.WaitForComplete();
                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return result;
        }
    }

    enum PremiumPeriod
    {
        _48Hours,
        _1Month,
        _3Months,
        _6Months,
        _1Year
    }
}
